package miniscala
import parser.Parser

object Test {
  def main(args: Array[String]): Unit ={

  }
}
