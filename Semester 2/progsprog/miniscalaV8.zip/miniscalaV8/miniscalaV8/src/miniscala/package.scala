package object miniscala {

}
