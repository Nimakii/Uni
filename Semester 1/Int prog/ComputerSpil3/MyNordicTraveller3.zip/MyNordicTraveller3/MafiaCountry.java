import java.util.*;
import java.util.Random;
/**
 * A mafiacountry represents a country,but each time you visit a city inside the country you risk getting robbed! The mafiacountry has a name and is a
 * collection of cities and roads between them, all part of a game. 
 *
 *  @author Jens Kristian & Thomas  Vinther
 * @version Computergame 2
 */
public class MafiaCountry extends Country
{
    private Random random;

    /**
     * Constructor for objects of class MafiaCountry
     */
    public MafiaCountry(String name, Map<City,List<Road>> network)
    {
        super(name, network);
        this.random = new Random();
    }

    /**
     * Calculates a random integer between 0 and value based upon the Random implemented in the Game Class.
     * 
     * @param value the value used in calculations
     * @return      either a random integer between 0 and value or a negative integer from game, between paramaters minirobbery and max robbery.  
     */
    @Override
    public int bonus(int value){
        if(random.nextInt(100)+1 > getGame().getSettings().getRisk()){
            return super.bonus(value);
        }
        return -getGame().getLoss();
    }

}
