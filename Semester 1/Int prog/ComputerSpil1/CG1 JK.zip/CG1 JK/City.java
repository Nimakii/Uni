import java.util.*;
/**
 * Write a description of class City here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class City implements Comparable<City>
{
    private String name;
    private int value;
    private int initialValue;
    private Country country;
    
    public City(String name, int value, Country country){
        this.name = name;
        this.value = value;
        this.initialValue = value;
        this.country = country;
    }
    
    public String getName(){
        return name;                          
    }
    public int getValue(){
        return value;                         
    }
    public void changeValue(int amount){
        value += amount;
    }
    public void reset(){
        value = initialValue;
    }
    public int compareTo(City c){
        return this.name.compareTo(c.getName());   
    }
    public Country getCountry(){
        return country;                       
    }
    
    public int arrive(){
        int bonus   = country.bonus(value);
        value -= bonus;
        return bonus;
    }
}